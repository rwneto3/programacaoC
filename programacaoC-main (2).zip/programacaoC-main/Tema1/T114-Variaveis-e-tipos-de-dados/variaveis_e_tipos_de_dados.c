#include <stdio.h>

int main(){
    int idade = 25;
    int quantidade = 1;
    float altura = 1.75;
    double peso = 90.3;
    char letra = 'A';
    char nome[20] = "Rafael";
    

    
return 0;
}