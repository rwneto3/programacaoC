#include <stdio.h>

int main(){

    printf("\n");
    printf("\n");
    printf("Olá, Mundo!\n");
    printf("\n");

return 0;

}