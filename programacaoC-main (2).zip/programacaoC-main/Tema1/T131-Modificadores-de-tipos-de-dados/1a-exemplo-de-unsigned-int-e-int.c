#include <stdio.h>
 
int main() {
    int signedNumber = 3000000000; // Este valor excede o limite de um int normal
    unsigned int unsignedNumber = 3000000000;
 
    printf("Número com sinal: %d\n", signedNumber);
    printf("Número sem sinal: %u\n", unsignedNumber);
    printf(" \n");
 /*
 unsigned int pode ser usado para variável inteira 'int' ou variável "char'
 */
    return 0;
}