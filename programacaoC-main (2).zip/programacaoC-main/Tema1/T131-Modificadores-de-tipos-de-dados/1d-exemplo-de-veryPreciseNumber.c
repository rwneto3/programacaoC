#include <stdio.h>
 
int main() {
    unsigned long int largePositiveNumber = 4000000000;
    printf("Número positivo grande: %lu\n", largePositiveNumber);
 
    return 0;
}