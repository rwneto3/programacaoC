#include <stdio.h>
 
int main() {
    
    printf("Tamanho de INT: %u bytes\n", sizeof(int));
    printf("Tamanho de LONG INT: %u bytes\n", sizeof(long int));
    printf("Tamanho de Long long INT: %u bytes\n", sizeof(long long int));
    printf("Tamanho de DOUBLE: %u bytes\n", sizeof(double));
    printf("Tamanho de LONG DOUBLE: %u bytes\n", sizeof(long double));
    printf(" \n");
 
    return 0;
}