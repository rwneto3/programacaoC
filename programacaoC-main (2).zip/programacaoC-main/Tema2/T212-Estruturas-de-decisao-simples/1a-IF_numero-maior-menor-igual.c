#include <stdio.h>

int main(){
    /*
    if (condicao) {
        //bloco de codigo a ser executado
        comando1
        comando2
    }
            
    */
    int numero1, numero2;

    numero1 = 5;
    numero2 = 5;

    if (numero1 > numero2) {
        printf("Número 1 é maior que Número 2 \n");
        
    }

    printf("Fora IF \n");
   
    return 0;
}