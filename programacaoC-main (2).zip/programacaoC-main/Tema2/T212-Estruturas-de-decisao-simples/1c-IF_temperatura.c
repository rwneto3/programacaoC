#include <stdio.h>

    int main(){

        float temperatura = 30.0;

        if(temperatura >= 30.0){
            printf("Está calor! \n");
        }

           //printf("FORA DO IF \n");
    }
