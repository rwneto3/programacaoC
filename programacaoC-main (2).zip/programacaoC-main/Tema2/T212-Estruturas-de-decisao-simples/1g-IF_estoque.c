#include <stdio.h>

    int main(){

        int estoque = 3;

        //printf("Verificar se o número %d é par... \n", numero);
        //printf("A variável Resultado (%d dividido por 2) tem resto: %d \n", numero, resultado);

        if (estoque <= 5) {
            printf("Estoque baixo \n");
            

        }
        
       // if(numero % 2 != 0){
       //    printf("A variável Resultado tem resto 1 (UM), então o numero %d é ímpar \n", numero);
       //}
          
    
    
    return 0;

    }
