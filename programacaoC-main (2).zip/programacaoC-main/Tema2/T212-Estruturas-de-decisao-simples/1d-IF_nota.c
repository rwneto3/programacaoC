#include <stdio.h>

    int main(){

        int nota = 70;

        if(nota >= 60){
            printf("Parabéns! Você é um GÊNIO! \n");
        }

           printf("SEU ASNO! Rodou bonito hein!? \n");
        
          
    
    
    return 0;

    }


